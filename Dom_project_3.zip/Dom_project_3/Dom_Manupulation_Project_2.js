var teams = [
    {
        name: "CSK",
        pri: "#F9CD05",
        sec: "#0081C8"
    },
    {
        name: "DC",
        pri: "#17479E",
        sec: "#EF1B23"
    },
    {
        name: "GT",
        pri: "#1C1C1C",
        sec: "#B5A36A"
    },
    {
        name: "KKR",
        pri: "#3A225D",
        sec: "#B3A123"
    },
    {
        name: "LSG",
        pri: "#A72056",
        sec: "#FFCC00"
    },
    {
        name: "MI",
        pri: "#004BA0",
        sec: "#D1AB3E"
    },
    {
        name: "PBKS",
        pri: "#ED1B24",
        sec: "#A7A9AC"
    },
    {
        name: "RR",
        pri: "#EA1A85",
        sec: "#254AA5"
    },
    {
        name: "RCB",
        pri: "#D71920",
        sec: "#F2A900"
    },
    {
        name: "SRH",
        pri: "#FF822A",
        sec: "#1E3A8A"
    }
];


var btn=document.querySelector('button')
var h1=document.querySelector('h1')

btn.addEventListener('click',function(){
    var num=Math.floor(Math.random()*teams.length);
    var winner=teams[num];
    h1.innerHTML=winner.name;
    h1.style.backgroundColor=winner.pri;
    h1.style.backgroundColor=winner.sec;

})