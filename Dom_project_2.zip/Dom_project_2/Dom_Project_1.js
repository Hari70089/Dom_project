let color_name=["red","green","blue","yellow","orange","pink","purple"]
var btn=document.querySelector("button")
var h1=document.querySelector('h1')
btn.addEventListener('click',function(){
    var name=Math.floor(Math.random()*color_name.length)
    var guess_name=color_name[name];
    console.log(guess_name);
    h1.innerHTML=guess_name;
})


