var bttn=document.querySelector('button')
var h5=document.querySelector('h5')

var flag=0

bttn.addEventListener('click',function(){
    if(flag==0){
    bttn.innerHTML='Adding..'
    h5.innerHTML='Request sending..'
    h5.style.color='gold'

    setTimeout(function(){
        bttn.innerHTML="Remove Friend"
        h5.innerHTML="Requst Accept"
        h5.style.color="Green"
        flag=1
    },5000)

    }else
        {
        bttn.innerHTML='Add Friend'
        h5.innerHTML='Stranger'
        h5.style.color='Red'
        flag=0

    }
})
































// // 2)setInterval
      


