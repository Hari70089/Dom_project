var btn=document.querySelector('button')
var percnte=document.querySelector('#percentage')
var growth=document.querySelector('#growth')
var grow=0

btn.addEventListener('click',function(){
    var finish=setInterval(function(){
        grow++
        percnte.innerHTML=grow+"%"
        growth.style.width=grow+'%'
    },50)

    setTimeout(function(){
        clearInterval(finish)
        btn.innerHTML='Downloaded'
        btn.style.opacity=.5
    },5000)

})















// var i=1
// var print=setInterval(function(){
//     console.log("hello",i++)
// },100)


// setTimeout(function(){
//     clearInterval(print)
// },3000)