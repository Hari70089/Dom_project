var bullb=document.getElementsByClassName('bulb')[0];
var bttn=document.getElementsByClassName('btn')[0];

let isOn=false;



bttn.addEventListener('click',function(){
   if(isOn){
    bullb.src="https://www.w3schools.com/js/pic_bulboff.gif";
    bttn.innerText="Turn On";
    isOn=false;
   }else{
    bullb.src="https://www.w3schools.com/js/pic_bulbon.gif";
    bttn.innerText="Turn Off";
    isOn=true;
   }
});
